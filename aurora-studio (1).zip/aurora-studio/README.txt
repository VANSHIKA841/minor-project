Aurora Studio — Responsive Landing Site (HTML + CSS only)
=======================================================

How to open
-----------
1. Unzip the project (if zipped).
2. Open `index.html` in your browser to view the site.
3. Other pages: `about.html`, `contact.html`.

What you'll find
----------------
- Three pages: index.html, about.html, contact.html
- External stylesheet: css/style.css
- Images: simple SVG placeholders in images/
- No JavaScript required for navigation, gallery, or interactions.

CSS-only techniques used
------------------------
- Mobile navigation implemented with the checkbox "nav-toggle" (checkbox hack).
- Image gallery lightbox implemented with anchor + :target overlays (no JS).
- Responsive layout using CSS Grid and Flexbox (mobile-first).
- CSS custom properties (variables) for colors, spacing, and typography.
- Print stylesheet rules included via @media print.
- prefers-reduced-motion support to disable animations for users who prefer reduced motion.

Accessibility notes
-------------------
- Skip-to-content link included.
- Semantic HTML elements (header, nav, main, section, article, footer).
- Images include alt attributes (decorative images left empty).
- Form controls have labels and are keyboard-accessible.
- Focus styles preserved for keyboard users.
- Color contrast considered for body text (WCAG AA compliant for normal text).

Known issues / limitations
--------------------------
- Images are simple SVG placeholders; replace them with real project images as needed.
- The year in the footer is set using a tiny inline script for preview convenience; remove script if you prefer pure HTML.
- Form is non-functional (action="#") as requested.

Files
-----
- index.html
- about.html
- contact.html
- css/style.css
- images/*.svg
- README.txt

Enjoy — built with only HTML & CSS :)
